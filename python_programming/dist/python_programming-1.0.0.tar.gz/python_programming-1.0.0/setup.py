from distutils.core import setup

setup(
    name='python_programming',
    version='1.0.0',
    packages=['lesson_package', 'lesson_package.talk', 'lesson_package.tool'],
    url='https://www.yahoo.co.jp/',
    license='Free',
    author='yheci',
    author_email='yheciix3kf3kf@gmail.com',
    description='Sample Package'
)
